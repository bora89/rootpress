<?php 

class SSWordpressClient extends SSClientBase {

    const TYPE_PLUGIN = 'plugin';
    const TYPE_THEME = 'theme';
}
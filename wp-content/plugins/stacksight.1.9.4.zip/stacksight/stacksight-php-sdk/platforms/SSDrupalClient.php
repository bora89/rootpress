<?php 

class SSDrupalClient extends SSClientBase {
    const TYPE_MODULE = 'module';
    const TYPE_THEME = 'theme';
}
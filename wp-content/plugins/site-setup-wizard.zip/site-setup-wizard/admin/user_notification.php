<?php

/* Notify the site admin that his site is now created and activated with all the features he selected */
wpmu_welcome_notification( $new_blog_id, $admin_user_id, $password, $title );

?>
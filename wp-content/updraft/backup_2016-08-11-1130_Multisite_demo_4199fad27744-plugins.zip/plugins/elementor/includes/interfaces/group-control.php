<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

interface Group_Control_Interface {
	public static function get_type();
}

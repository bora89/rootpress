evolve WordPress Theme By Theme4Press - http://theme4press.com
Licensed under GNU General Public License v2.0 - http://www.gnu.org/licenses/gpl-2.0.html
-------------------------------------------------------------------------------------------------

Additional Licenses
-------------------

Redux Framework - https://reduxframework.com/ - GPL License
FontAwesome Icons - http://fortawesome.github.io/Font-Awesome/ - GPL License
Bootstrap - http://getbootstrap.com/ - MIT License
Parallax Slider - http://tympanus.net/codrops/2012/03/15/parallax-content-slider-with-css3-and-jquery/ - GPL License
AnythingSlider - http://css-tricks.com - GPL License 
Custom DropDown plugin - http://designwithpc.com - GPL License
jQuery goMap - http://www.pittss.lv/jquery/gomap/ - MIT License
hoverIntent - http://cherne.net/brian/resources/jquery.hoverIntent.html - GPL License
jQuery Superfish Menu Plugin - http://plugins.jquery.com/superfish/ - GPL License
Supersubs - http://users.tpg.com.au/j_birch/plugins/superfish/ - GPL License
Tipsy - http://onehackoranother.com/projects/jquery/tipsy/ - GPL License
Infinite Ajax Scroll - http://infiniteajaxscroll.com - MIT License
IcoMoon Fonts - https://icomoon.io - GPL License   


Bootstrap Slider pictures - CC0 1.0 Universal:
Sylwia Bartyzel - https://twitter.com/SylwiaBartyzel
Ben Moore - http://twitter.com/benmooredaily
Vee-O - http://dribbble.com/veeo
Wolfgang Moritzer - http://500px.com/wmoritzer
Lukas Schweizer - http://www.lukas-schweizer.ch/

Additional photos - CC0 1.0 Universal:
Philipp Reiner - http://www.philippreiner.de/
Vee-O - http://dribbble.com/veeo

Other images (icons, theme images, background images, etc.) are licensed under GPL v2.0.


